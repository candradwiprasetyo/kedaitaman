<?php

function new_date(){
	$new_date = date("Y-m-d H:m:s");
	return $new_date;
}

?>