 <aside class="left-side sidebar-offcanvas">                
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="img/candramelon.png" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p>Hello, Candra</p>

                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                   
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                     
                        <li>
                            <a href="index.php">
                                <i class="fa fa-home"></i> <span>Home</span> 
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=pages/about_me">
                                <i class="fa fa-user"></i> <span>About Me</span> 
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=pages/my_timeline">
                                <i class="fa fa-th"></i> <span>My Timeline</span> 
                            </a>
                        </li>
                        <li>
                            <a href="../index.php?page=pages/latest_work">
                                <i class="fa fa-laptop"></i> <span>My Latest Work</span> 
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=pages/testimonial">
                                <i class="fa fa-comment"></i> <span>Testimonial</span> 
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=pages/update_list">
                                <i class="fa fa-envelope-o"></i> <span>Update List</span> 
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=pages/contact_list">
                                <i class="fa  fa-phone"></i> <span>Contact List</span> 
                            </a>
                        </li>
                       
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>