<div id="about_page"></div>
<div class="overlay_new"></div>
    <section class="about" id="about" style="padding-bottom:0px !important">
      <div class="container">
        <div class="row">

          <div class="col-md-12">

          <div class="col-md-12 title text-center wow animated fadeInUp" data-wow-delay="0.1s">
          <div class="new_title">Tentang <strong>Kami</strong></div>
          </div>

          <div class="col-md-5 title text-center wow animated fadeInLeft" data-wow-delay="0.1s">

          <div class="content_putih">
             <img src="images/about.jpg" class="img_about">
            <div class="content_putih_desc">
<p><b>Soto Kudus Kedai Taman</b> adalah restoran soto kudus yang terletak di 
              selatan surabaya tepatnya di dekat Masjig Agung Surabaya.</p>
              <p>
              Soto Kudus Kedai Taman berada di Jalan Gayungsari Timur X No 1 Surabaya. 
              Lokasi di Surabaya Selatan, dan 10 menit dari Bandara Internasional Juanda.
              </p>
            </div>
          </div>
          
          </div>
          <br>

          <div class="col-md-7 wow animated fadeInRight">

          <div class="content_putih">
            <div class="content_putih_desc">
             <p><b>Soto Kudus Kedai Taman</b> memiliki menu yang khas, terutama masakan khas Kota Kudus. Yang paling terkenal <b>ENAK</b> dan <b>LEZAT</b> adalah Menu Soto Kudus dengan kecap asli Kudus yang oleh pelanggan kami diberi predikat The Best Menu of Soto Kudus Kedai Taman.
              </p>
              <p>Soto Kudus Kedai Taman dikelola oleh tangan-tangan terampil dan berpengalaman dengan pola management dan penyajian yang Profesional.</p>
             <p>Kami juga melayani pemesanan untuk acara spesial Anda seperti Buka Puasa, Akad Nikah, 
              Pesta Pernikahan Arisan, Senam Pagi, Meetting, Gathering, Syukuran dan sebagainya.</p>
              <p> 
            </div>
          </div>
          <br>
          
         
          <div class="content_putih">
            <div class="content_putih_desc" style="text-align:center; padding-top:20px;">
             
                <b>Informasi lebih lanjut dan pemesanan klik</b>
               
              
              <a href="#"><div class="button_about_pesan">Pesan</div></a>
              
            </div>
          </div>

          </div>

        
          </div>

         
          
          
          
        
         </div>

        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.features -->
    <!-- about section END -->
  <br>