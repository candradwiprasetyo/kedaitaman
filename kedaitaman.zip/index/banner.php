<!-- banner section BEGIN -->
    <section class="banner" id="home" style="margin-bottom:60px;">
      <div class="overlay"></div>
      <div class="banner-content">
        <div class="container">
          
          <div class="col-md-12 wow animated fadeInUp">

            <div class="title">
            	<div class="icon_logo"></div>
             
            </div>
          
        
        </div>
           
         <div class="col-md-12 wow animated fadeInUp">
<!--
            <ul class="new_topmenu">
            <li>Home</li>
            <li>Home</li>
            <li>Home</li>
            <li>Home</li>
            <li>Home</li>
          </ul>

-->
      <section class="slider">
        <div class="flexslider">
          <ul class="slides">
            <li data-thumb="images/slider/1.jpg">
              <img src="images/slider/1.jpg" />
              <p class="flex-caption"><b>Soto</b> Kudus</p>
            </li>
            <li data-thumb="images/slider/2.jpg">
              <img src="images/slider/2.jpg" />
              <p class="flex-caption"><b>Ayam</b> Bakar</p>
            </li>
            <li data-thumb="images/slider/3.jpg">
              <img src="images/slider/3.jpg" />
              <p class="flex-caption"><b>Lontong Pecel</b></p>
            </li>
             <li data-thumb="images/slider/4.jpg">
              <img src="images/slider/4.jpg" />
              <p class="flex-caption"><b>Es</b> Teler</p>
            </li>
          </ul>
        </div>
      </section>
      </div>
            
         
        </div><!-- /.container -->
      </div><!-- /.banner-content -->
       
    </section><!-- /.banner -->
    
