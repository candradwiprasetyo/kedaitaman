<!-- clients section BEGIN  -->
    <section class="clients">
      <div class="container">
        <div class="title text-center wow animated fadeInUp">
          <h1>Our Satisfied Client</h1>
        </div>
        <div class="description wow animated fadeInLeft">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.</p>
        </div>

        <div id="clients" class="clients-logo owl-theme wow animated fadeIn">
          <div class="item">
            <a href="#"><img src="assets/images/client1.png" alt="clients"></a>
          </div>
          <div class="item">
            <a href="#"><img src="assets/images/client2.png" alt="clients"></a>
          </div>
          <div class="item">
            <a href="#"><img src="assets/images/client3.png" alt="clients"></a>
          </div>
          <div class="item">
            <a href="#"><img src="assets/images/client4.png" alt="clients"></a>
          </div>
          <div class="item">
            <a href="#"><img src="assets/images/client5.png" alt="clients"></a>
          </div>
          <div class="item">
            <a href="#"><img src="assets/images/client6.png" alt="clients"></a>
          </div>
        </div>
      </div>
    </section>
    <!-- clients section END  -->