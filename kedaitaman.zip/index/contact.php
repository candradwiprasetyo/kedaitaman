<!-- contact section BEGIN  -->
    <section class="contact" id="contact">
      <div class="container"> 
        <div class="title text-center wow animated fadeInDown"><h1>Kontak <strong>Kami</strong></h1></div> 
        

        <div class="col-md-12">
        <div class="col-md-8">
          <div class="footer-form">
            <form role="form">
              <div class="col-md-6 wow animated fadeInUp" data-wow-delay="0.2s">
                <input type="text" class="form-control" placeholder="Nama">
              </div>
              <div class="col-md-6  wow animated fadeInUp" data-wow-delay="0.2s">
                <input type="text" class="form-control" placeholder="Telepon">
              </div>
              <div class="col-md-12  wow animated fadeInUp" data-wow-delay="0.4s">
                <input type="text" class="form-control" placeholder="Judul">
              </div>
              <div class="col-md-12 wow animated fadeInUp" data-wow-delay="0.6s">
                <textarea rows="3" class="form-control" placeholder="Keterangan" style="max-width:100%; min-width:100%; min-height:100px;"></textarea>
              </div>
              <div class="col-md-12 button-container wow animated fadeInUp" data-wow-delay="0.8s">
                <input type="submit" class="submit-btn def-btn" value="Kirim Pesan">
              </div>
            </form>
            </div>
           
            </div>
            
             <div class="col-md-4">
            <div class="title text-center wow animated fadeInRight"><h1 style="margin-top:0px;">Lokasi  <strong>Restoran</strong></h1></div> 
            <div class="description wow animated fadeInRight" style="margin-bottom:-20px;">
          <p>
           Soto Kudus Kedai Taman  <br/>
Gayungsari Timur X No 1 <br/>
Surabaya, Jawa Timur, Indonesia <br/>
(0838) 31059355 <br/>
kedaitaman@gmail.com 
          </p>
          
        </div>
         <div class=" text-center wow animated fadeInRight">
            <ul class="icons">
					
					<li><a href="#" class="icon circle fa-facebook"><span class="label">Facebook</span></a></li>
					<li><a href="#" class="icon circle fa-google-plus"><span class="label">Google+</span></a></li>
					<li><a href="#" class="icon circle fa-github"><span class="label">Github</span></a></li>
				</ul>
            </div>
          </div><!--/.footer-form -->
        </div>
        
      </div>
    </section>
    <!-- contact section END  -->