<!-- feature section BEGIN  -->
    <section class="why-us" id="why-us">
      <div class="container">

        <div class="col-md-6 text wow animated fadeInDown">
          <div class="title"><h1>Why Choose Us?</h1></div>
          <div class="tagline wow animated fadeInLeft">
            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.</p>
          </div>
          <div class="description wow animated fadeInLeft">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi labore et dolore magna aliqua consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua consectetur adipisicing elit, sed do eiusmod.</p>
          </div>
        </div>

        <div class="col-md-6 skills">
          <div class="title wow animated fadeInDown">
            <h3>We Are Good At</h3>
          </div>
          <div class="skillbars">
            <div class="bar-container">
              <p><i class="icon-pencil pi-icon-left"></i>HTML CSS3</p>
              <div class="meter wow animated fadeInLeft" style="width: 80%"></div>
            </div>
            <div class="bar-container">
              <p><i class="icon-pencil pi-icon-left"></i>Photoshop</p>
              <div class="meter wow animated fadeInLeft" style="width: 90%"></div>
            </div>
            <div class="bar-container">
              <p><i class="icon-pencil pi-icon-left"></i>Ilustrator</p>
              <div class="meter wow animated fadeInLeft" style="width: 40%"></div>
            </div>
            <div class="bar-container">
              <p><i class="icon-pencil pi-icon-left"></i>Java Script</p>
              <div class="meter wow animated fadeInLeft" style="width: 50%"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- feature section END  -->