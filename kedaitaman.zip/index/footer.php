
 <!-- footer section START  -->
    <section class="footer">
    	 <div class="overlay"></div>
      <div class="container">
        <div class="col-md-12 col-sm-12">
        
          © Copyright 2015 All right reserved.
        </div>
        
      </div><!--/.container -->
    </section>
    <!-- footer section END  -->