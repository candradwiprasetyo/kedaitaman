<!-- about section BEGIN -->
    <section class="about">
      <div class="container">
        <div class="row">
    
          <div class="col-md-12">
          
          <div class="col-md-4 feature wow animated fadeInUp" data-wow-delay="0.3s">
            <a href="#" >
            <div class="content">
              <div class="category_name color1">Makanan</div>
              <div class="icon">
                <img src="images/category/1a.png" class="category_img">
             </div>
             <div class="category_lookup lookup1"></div>
             
            </div>
          </a>
          </div>

         <div class="col-md-4 feature wow animated fadeInUp" data-wow-delay="0.3s">
            <a href="#">
            <div class="content">
              <div class="category_name color2">Minuman</div>
              <div class="icon">
                <img src="images/category/2a.png" class="category_img">
             </div>
             <div class="category_lookup lookup2"></div>
             
            </div>
          </a>
          </div>
  
          <div class="col-md-4 feature wow animated fadeInUp" data-wow-delay="0.3s">
            <a href="#">
            <div class="content">
              <div class="category_name color3">Snack</div>
              <div class="icon">
                <img src="images/category/3.png" class="category_img">
             </div>
             <div class="category_lookup lookup3"></div>
             
            </div>
          </a>
          </div>

        </div>


        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.features -->
    <!-- about section END -->