<!-- offer section BEGIN  -->
    <section class="offer text-center">
      <div class="overlay"></div>
      <div class="container">
        <div class="content">
          <div class="title wow animated fadeInDown"><h1>Awesome , Right?</h1></div>
          <div class="description wow animated fadeInLeft">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.</p>
          </div>
          <a href="#" class="def-btn wow animated fadeInUp">Let's Buy it</a>
        </div>
      </div>
    </section><!--/.offer -->
    <!-- offer section END  -->