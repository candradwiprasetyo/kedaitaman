<!-- pricing section BEGIN  -->
    <section class="pricing" id="pricing">
      <div class="container">
        <div class="title text-center wow animated fadeInDown"><h1>Pricing <strong>Table</strong></h1></div>
         <!--<div class="description wow animated fadeInLeft">
         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.</p>
        </div>-->

       
		<!--
        <div class="col-md-4 col-sm-6">
        
          <div class="pricing-table wow animated fadeInUp" data-wow-delay="0.3s" 
          
          style="
          box-shadow: 0px 0px 20px 10px rgba(255,255,255,1);
	-webkit-transform: scale(0.9);
	-moz-transform: scale(0.9);
	-o-transform: scale(0.9);
	-ms-transform: scale(0.9);
	transform: scale(0.9);
	opacity: 0.7;" ><div class="blokir"></div>
            <div class="header">
              <h3 style="text-shadow: 0px 0px 5px rgba(0, 0, 0, 0.9);
	color: rgba(0, 0, 0, 0);
	opacity: 0.5;">Personal</h3></div>
            <div class="price" style="box-shadow: 0px 0px 20px 10px #67A1C6;
	-webkit-transform: scale(1);
	-moz-transform: scale(1);
	-o-transform: scale(1);
	-ms-transform: scale(1);
	transform: scale(1);
	opacity: 0.7;"><div style="text-shadow: 0px 0px 5px 10px #fff;
	color: #fff;
	opacity: 0.5;"><span class="textbold" >$5</span> / hours</div></div>
            <div class="list">
              <ul style="text-shadow: 0px 0px 5px rgba(0, 0, 0, 0.9);
	color: rgba(0, 0, 0, 0);
	opacity: 0.5;">
                <li><span class="textbold">Up to</span> 5 Users</li>
                <li><span class="textbold">Max</span> 100 items</li>
                <li><span class="textbold">Unlimited</span> QueriesFull</li>
                <li><span class="textbold">Statistics</span></li>
              
              </ul>
              <a class="def-btn" style=" border:0px;  box-shadow: 0px 0px 20px 10px rgba(255,255,255,1);
	-webkit-transform: scale(0.9);
	-moz-transform: scale(0.9);
	-o-transform: scale(0.9);
	-ms-transform: scale(0.9);
	transform: scale(0.9);
	opacity: 0.7">Get This Plan</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-12 col-md-offset-1">-->
        
        <div class="col-md-4 col-sm-6">
          <div class="pricing-table wow animated fadeInUp" data-wow-delay="0.3s">
            <div class="pricing_block"></div>
          </div>
        </div>

        <div class="col-md-4 col-sm-6">
          <div class="pricing-table active wow animated fadeInUp" data-wow-delay="0.1s">
            <div class="header">
              <h3>RECOMMENDED</h3></div>
            <div class="price"><span class="textbold">NEGOTIABLE</span></div>
            <div class="list">
              <ul>
                <li><span class="textbold">Have a <strong>Awesome Project ?</strong> </span></li>
                <li><span class="textbold">Need creative <strong>help ?</strong> </span></li>
                <li><span class="textbold">Or want to make the <strong>Team ?</strong></span> </li>
                <li><span class="textbold">And wants to change the <strong>WORLD ?</strong> </span></li>
                <li><span class="textbold"></span></li>
                <li><span class="notice">Dont waste ur time !</span></li>
              </ul>
              <a class="def-btn" href="#"><strong>Get In Touch</strong></a>
            </div>
          </div>
        </div>

        <div class="col-md-4 col-sm-6">
          <div class="pricing-table wow animated fadeInUp" data-wow-delay="0.3s">
            <div class="pricing_block"></div>
          </div>
        </div>
        
     

      </div>
    </section>
    <!-- pricing section END  -->