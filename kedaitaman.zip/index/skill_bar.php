<section class="skill_bar" id="skill_bar">
                
<div class="container">
<div class="col-md-12 text-center wow animated fadeInDown">
<div class="title"><h1>My <strong>Skill</strong></h1></div>
</div>
						<div class="row">

							<div class="col-md-6 text wow animated fadeInLeft">
							<div class="item_frame">
								<section>
									<div class="skill_title">PHP</div>
									<div class="progress-wrap1 progress" data-progress-percent1="50">
									  50 %<div class="progress-bar1 progress"></div>

									</div>
									
									
								</section>
							</div>
						  </div>
                          
                          <div class="col-md-6 text wow animated fadeInRight">
							<div class="item_frame">
								<section>
									<div class="skill_title">MySQL</div>
									<div class="progress-wrap6 progress" data-progress-percent6="70">
									  70 %<div class="progress-bar6 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>

							<div class="col-md-6 text wow animated fadeInLeft">
							<div class="item_frame">
								<section>
									<div class="skill_title">jQuery</div>
									<div class="progress-wrap2 progress" data-progress-percent2="45">
									45 %  <div class="progress-bar2 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>

						  <div class="col-md-6 text wow animated fadeInRight">
							<div class="item_frame">
								<section>
									<div class="skill_title">HTML5</div>
									<div class="progress-wrap3 progress" data-progress-percent3="65">
									  65 %<div class="progress-bar3 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>

							<div class="col-md-6 text wow animated fadeInLeft">
							<div class="item_frame">
								<section>
									<div class="skill_title">Graphic Design</div>
									<div class="progress-wrap4 progress" data-progress-percent4="60">
									  60 %<div class="progress-bar4 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>
                          
                         <div class="col-md-6 text wow animated fadeInRight">
							<div class="item_frame">
								<section>
									<div class="skill_title">CSS3</div>
									<div class="progress-wrap5 progress" data-progress-percent5="55">
									  55 %<div class="progress-bar5 progress"></div>

									</div>

									
								</section>
							</div>
						  </div>
                          
                          


						</div>
						
					</div>
</section>