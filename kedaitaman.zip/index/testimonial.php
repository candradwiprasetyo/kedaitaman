 <!--<div id="update_page"></div>    testimonial section BEGIN-->
    <section class="testimonial text-center" id="testimonial">
      <div class="overlay"></div>
      
      <div id="testimonial-carousel" class="carousel slide" data-ride="carousel">
     
        <div class="container wow animated fadeInUp" data-wow-delay="0s">
          <div class="carousel-inner">
         
           
            <div class="item active">
             <div class="col-md-2 col-md-offset-1 title text-center">
           <img src="images/candramelon.png" alt="img01" class="img_about" />
          </div>
          <div class="col-md-8 title text-center">
              <div class="title_testimonial">
                Soto Kudusnya enak
              </div>
              <div class="text">
                " Soto Kudus Kedai Taman ini letaknya deket banget sama kosan gw, jadi suka deh kesini plus emang soto kudusnya enak juga sih.  "
              </div>
              <div class="name">
                <span class="textbold">Henny</span>, Mahasiswa
              </div>
            </div>
            </div>

            <div class="item">
               <div class="col-md-2 col-md-offset-1 title text-center">
           <img src="images/candramelon.png" alt="img01" class="img_about" />
          </div>
          <div class="col-md-8 title text-center">
            <div class="title_testimonial">
                Suasana & Service
              </div>
              <div class="text">
                " Pelayanannya  baik dan cepat, baru duduk udah ditanyaan mau makan apa, 
                kebersihan dijaga dengan baik oleh pengelolanya. 
                Tempat makannya  enak rindang karena pohon besarnya dan konsep restorannya yang seperti kedai  "
              </div>
              <div class="name">
                <span class="textbold">Fevorite</span>, Mahasiswa
              </div>
            </div>
            </div><!--/.item -->


            <div class="item">
               <div class="col-md-2 col-md-offset-1 title text-center">
           <img src="images/candramelon.png" alt="img01" class="img_about" />
          </div>
          <div class="col-md-8 title text-center">
            <div class="title_testimonial">
                Tempat sangat nyaman 
              </div>
              <div class="text">
                " Salah satu keunggulan rumah makan ini disediakan, toilet yang bersih, westafel dan juga parkiran yang luas, jadi gak perlu khawatir bagi anda yang ingin mengunjungi tempat ini dengan kendaraan roda dua atau roda empat"
              </div>
              <div class="name">
                <span class="textbold">Agree</span>, Mahasiswa
              </div>
            </div>
            </div><!--/.item -->

                        
          </div><!--/.carousel-inner -->
        </div><!--/.container -->

        <!-- Controls -->
        <a class="left carousel-control wow animated fadeIn" href="#testimonial-carousel" role="button" data-slide="prev" data-wow-delay="1s">
          <div class="control-circle left"><i class="fa fa-angle-left"></i></div>
        </a>
        <a class="right carousel-control wow animated fadeIn" href="#testimonial-carousel" role="button" data-slide="next" data-wow-delay="1s">
          <div class="control-circle right"><i class="fa fa-angle-right"></i></div>
        </a>
      </div><!--/.testimonial-carousel -->
    </section><!--/.testimonial -->
    <!-- testimonial section END-->