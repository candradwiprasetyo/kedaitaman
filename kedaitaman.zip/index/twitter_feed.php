 <!-- twitter-feed section BEGIN  -->
    <section class="twitter-feed">
      <div class="logo wow animated fadeInDown"><i class="fa fa-twitter"></i></div>
       <div id="twitter-carousel" class="carousel slide" data-ride="carousel">
        <div class="container wow animated fadeInUp">
          <div class="carousel-inner">
            <div class="item active">
              <div class="tweet">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
              </div>
            </div><!--/.item -->
            <div class="item">
              <div class="tweet">
                <p>Lorem ipsum dolor sit amet, <span class="textbold">@owlcity</span> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
              </div>
            </div><!--/.item -->
          </div><!--/.carousel-inner -->
          <div class="time wow animated fadeInUp">3 Days Ago From <a href="#">@suavedigital_ID</a></div>
        </div><!--/.container -->
      </div><!--/.twitter-carousel -->
    </section><!--/.twitter-feed -->
    <!-- twitter-feed section END  -->